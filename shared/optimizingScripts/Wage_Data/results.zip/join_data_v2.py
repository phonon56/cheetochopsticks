#!/usr/bin/env python3
"""
Compared to What — Dashboard Data Joiner (v2)
----------------------------------------------
Joins three datasets:
  1. BLS QCEW wage data (county-level)
  2. Zillow ZHVI typical home value (county-level)
  3. Zillow Income Needed to Buy (metro-level, with 20% down)

Computes affordability metrics:
  - Wage gap (Denver vs El Paso, dollars and percent)
  - Income shortfall (income needed minus actual wage)
  - Affordability coverage (actual wage as % of income needed)
  - Years of wages to buy a typical home

Inputs (must be in current directory):
  bls_wage_dashboard.csv          — output from bls_pull.py
  zhvi_county.csv                 — Zillow County ZHVI CSV (renamed)
  income_needed_metro.csv         — Zillow Metro "Income Needed" CSV (renamed)

Output:
  dashboard_data_v2.csv

Note on geographic levels:
  BLS and ZHVI are at the county level (El Paso County / Denver County).
  Income Needed is published at the metro level (Colorado Springs MSA / 
  Denver-Aurora-Lakewood MSA). The MSA contains the county plus surrounding
  areas — for our purposes, the metro figure is the closest available proxy
  for the county's housing market and is documented as such.

Usage:
  pip install pandas
  python3 join_data_v2.py
"""

import pandas as pd
import sys
from pathlib import Path

BLS_FILE = "bls_wage_dashboard.csv"
ZHVI_FILE = "zhvi_county.csv"
INCOME_FILE = "income_needed_metro.csv"
OUTPUT_FILE = "dashboard_data_v2.csv"

YEARS = list(range(2019, 2025))  # 2019 through 2024

COUNTIES = {
    "El Paso County": "elpaso",
    "Denver County": "denver",
}

METROS = {
    "Colorado Springs, CO": "elpaso",   # MSA proxy for El Paso County
    "Denver, CO":           "denver",   # MSA proxy for Denver County
}


def annual_average(row, date_cols, year):
    """Compute the annual average across all monthly columns in a given year."""
    year_cols = [c for c in date_cols if c.startswith(str(year))]
    if not year_cols:
        return None
    values = pd.to_numeric(row[year_cols], errors='coerce').dropna()
    return values.mean() if len(values) > 0 else None


def load_bls():
    path = Path(BLS_FILE)
    if not path.exists():
        sys.exit(f"ERROR: {BLS_FILE} not found. Run bls_pull.py first.")
    return pd.read_csv(path)


def load_zhvi():
    path = Path(ZHVI_FILE)
    if not path.exists():
        sys.exit(f"ERROR: {ZHVI_FILE} not found.")
    df = pd.read_csv(path)
    target = df[(df["StateName"] == "CO") & (df["RegionName"].isin(COUNTIES))].copy()
    if len(target) != 2:
        sys.exit(f"ERROR: Expected 2 ZHVI rows, got {len(target)}.")

    date_cols = [c for c in df.columns if "-" in str(c) and str(c)[:4].isdigit()]

    rows = []
    for year in YEARS:
        row = {"year": year}
        for _, county_row in target.iterrows():
            nickname = COUNTIES[county_row["RegionName"]]
            avg = annual_average(county_row, date_cols, year)
            row[f"{nickname}_typical_home_value"] = round(avg, 0) if avg else None
        rows.append(row)
    return pd.DataFrame(rows)


def load_income_needed():
    path = Path(INCOME_FILE)
    if not path.exists():
        sys.exit(f"ERROR: {INCOME_FILE} not found.\n"
                 f"Rename Metro_new_homeowner_income_needed_downpayment_0_20_uc_sfrcondo_tier_0_33_0_67_sm_sa_month.csv\n"
                 f"to {INCOME_FILE}.")
    df = pd.read_csv(path)
    target = df[(df["StateName"] == "CO") & (df["RegionName"].isin(METROS))].copy()
    if len(target) != 2:
        sys.exit(f"ERROR: Expected 2 Income Needed rows, got {len(target)}.")

    date_cols = [c for c in df.columns if "-" in str(c) and str(c)[:4].isdigit()]

    rows = []
    for year in YEARS:
        row = {"year": year}
        for _, metro_row in target.iterrows():
            nickname = METROS[metro_row["RegionName"]]
            avg = annual_average(metro_row, date_cols, year)
            row[f"{nickname}_income_needed"] = round(avg, 0) if avg else None
        rows.append(row)
    return pd.DataFrame(rows)


def compute_metrics(joined):
    """Compute the affordability metrics that drive the dashboard charts."""
    # Income shortfall: how much short of qualifying income is the average worker?
    joined["elpaso_income_shortfall"] = (
        joined["elpaso_income_needed"] - joined["elpaso_total_annual_wage"]
    ).round(0)
    joined["denver_income_shortfall"] = (
        joined["denver_income_needed"] - joined["denver_total_annual_wage"]
    ).round(0)

    # Coverage: actual wage as percent of income needed.
    # Higher = closer to affordability. 100% = average worker can afford typical home solo.
    joined["elpaso_wage_coverage_pct"] = (
        joined["elpaso_total_annual_wage"] / joined["elpaso_income_needed"] * 100
    ).round(1)
    joined["denver_wage_coverage_pct"] = (
        joined["denver_total_annual_wage"] / joined["denver_income_needed"] * 100
    ).round(1)

    # Years-of-wages ratio (the simpler home-value-to-wage metric, retained)
    joined["elpaso_years_of_wages"] = (
        joined["elpaso_typical_home_value"] / joined["elpaso_total_annual_wage"]
    ).round(2)
    joined["denver_years_of_wages"] = (
        joined["denver_typical_home_value"] / joined["denver_total_annual_wage"]
    ).round(2)

    return joined


def main():
    print("Compared to What — Dashboard Data Joiner v2")
    print("-" * 65)

    bls = load_bls()
    print(f"Loaded BLS wage data: {len(bls)} years")

    zhvi = load_zhvi()
    print(f"Loaded Zillow ZHVI (typical home value): {len(zhvi)} years")

    income = load_income_needed()
    print(f"Loaded Zillow Income Needed: {len(income)} years")

    # Merge all three on year
    joined = bls.merge(zhvi, on="year", how="inner").merge(income, on="year", how="inner")
    print(f"Joined dataset: {len(joined)} rows")

    final = compute_metrics(joined)

    # Reorder columns for clarity
    column_order = [
        "year",
        # Wages
        "elpaso_total_annual_wage", "denver_total_annual_wage",
        "wage_gap_total_usd", "wage_gap_total_pct",
        # Home values
        "elpaso_typical_home_value", "denver_typical_home_value",
        # Income needed (the main affordability anchor)
        "elpaso_income_needed", "denver_income_needed",
        # Computed affordability metrics
        "elpaso_income_shortfall", "denver_income_shortfall",
        "elpaso_wage_coverage_pct", "denver_wage_coverage_pct",
        "elpaso_years_of_wages", "denver_years_of_wages",
        # Employment (context)
        "elpaso_total_employment", "denver_total_employment",
    ]
    available = [c for c in column_order if c in final.columns]
    final = final[available]

    print("\nDashboard-ready dataset:")
    print(final.to_string(index=False))
    print()

    # Highlights
    print("\n" + "=" * 65)
    print("HEADLINE NUMBERS — 2024")
    print("=" * 65)
    row_2024 = final[final["year"] == 2024].iloc[0]
    print(f"\nEl Paso County:")
    print(f"  Average wage:           ${row_2024['elpaso_total_annual_wage']:>9,.0f}")
    print(f"  Income needed to buy:   ${row_2024['elpaso_income_needed']:>9,.0f}")
    print(f"  Shortfall:              ${row_2024['elpaso_income_shortfall']:>9,.0f}")
    print(f"  Wage covers:            {row_2024['elpaso_wage_coverage_pct']:>9.1f}% of income needed")
    print(f"\nDenver County:")
    print(f"  Average wage:           ${row_2024['denver_total_annual_wage']:>9,.0f}")
    print(f"  Income needed to buy:   ${row_2024['denver_income_needed']:>9,.0f}")
    print(f"  Shortfall:              ${row_2024['denver_income_shortfall']:>9,.0f}")
    print(f"  Wage covers:            {row_2024['denver_wage_coverage_pct']:>9.1f}% of income needed")

    final.to_csv(OUTPUT_FILE, index=False)
    print(f"\n✓ Written to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
