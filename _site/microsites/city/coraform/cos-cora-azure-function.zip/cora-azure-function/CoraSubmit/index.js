/**
 * CORA Records Request — Azure Function Handler
 * City of Colorado Springs
 *
 * Receives form submissions from the accessible CORA form,
 * sends a confirmation email to the resident, and routes
 * the request to the appropriate city department.
 *
 * Stack: Node.js 18+ · Azure Functions v3 · Nodemailer (Office 365 SMTP)
 * Built by StorySeed / The Dais · Offered to the City at no charge.
 */

'use strict';

const nodemailer  = require('nodemailer');
const { v4: uuid } = require('uuid');

// ── DEPARTMENT ROUTING MAP ────────────────────────────────────────
// Maps the form's department select value to a display label and
// the staff email address that should receive the routed request.
// Update these addresses to match actual city staff routing.
const DEPARTMENT_ROUTING = {
  procurement:    { label: 'Contracting / Procurement Services', email: process.env.EMAIL_PROCUREMENT   || 'procurement@coloradosprings.gov' },
  it:             { label: 'Information Technology',             email: process.env.EMAIL_IT             || 'it@coloradosprings.gov' },
  planning:       { label: 'Planning Department',                email: process.env.EMAIL_PLANNING       || 'planning@coloradosprings.gov' },
  traffic:        { label: 'Traffic and Transportation Engineering', email: process.env.EMAIL_TRAFFIC    || 'traffic@coloradosprings.gov' },
  police:         { label: 'Colorado Springs Police Department', email: process.env.EMAIL_POLICE         || 'pio@coloradosprings.gov' },
  fire:           { label: 'Fire Department',                    email: process.env.EMAIL_FIRE           || 'fire@coloradosprings.gov' },
  utilities:      { label: 'Colorado Springs Utilities',         email: process.env.EMAIL_UTILITIES      || 'coracustomerservices@csu.org' },
  municipal_court:{ label: 'Municipal Court',                    email: process.env.EMAIL_COURT          || 'MunicipalCourtViolations@coloradosprings.gov' },
  neighborhood:   { label: 'Neighborhood Services',              email: process.env.EMAIL_NEIGHBORHOOD   || 'neighborhoodservices@coloradosprings.gov' },
  public_works:   { label: 'Public Works',                       email: process.env.EMAIL_PUBLIC_WORKS   || 'publicworks@coloradosprings.gov' },
  finance:        { label: 'Finance / Accounts Receivable',      email: process.env.EMAIL_FINANCE        || 'finance@coloradosprings.gov' },
  city_attorney:  { label: 'City Attorney',                      email: process.env.EMAIL_CITY_ATTORNEY  || 'cityattorney@coloradosprings.gov' },
  mayor:          { label: "Mayor's Office",                     email: process.env.EMAIL_MAYOR          || 'mayor@coloradosprings.gov' },
  other:          { label: 'Multiple / Other Departments',       email: process.env.EMAIL_COORDINATOR    || 'City.Communications@coloradosprings.gov' },
  '':             { label: 'Unknown — needs routing',            email: process.env.EMAIL_COORDINATOR    || 'City.Communications@coloradosprings.gov' },
};

// Fallback for any department value not in the map
const DEFAULT_ROUTING = {
  label: 'General CORA Coordinator',
  email: process.env.EMAIL_COORDINATOR || 'City.Communications@coloradosprings.gov',
};

// ── REFERENCE NUMBER ─────────────────────────────────────────────
function generateReference() {
  const now  = new Date();
  const yr   = now.getFullYear();
  const mo   = String(now.getMonth() + 1).padStart(2, '0');
  const dy   = String(now.getDate()).padStart(2, '0');
  const rand = uuid().split('-')[0].toUpperCase(); // 8 hex chars
  return `CORA-${yr}${mo}${dy}-${rand}`;
}

// ── SMTP TRANSPORT ────────────────────────────────────────────────
// Uses Microsoft 365 SMTP relay — the City's existing mail infrastructure.
// If the City uses a dedicated SMTP relay or SendGrid, update host/port/auth.
function createTransport() {
  return nodemailer.createTransport({
    host:   process.env.SMTP_HOST   || 'smtp.office365.com',
    port:   parseInt(process.env.SMTP_PORT || '587', 10),
    secure: false, // STARTTLS on port 587
    auth: {
      user: process.env.SMTP_USER,   // e.g. cora-noreply@coloradosprings.gov
      pass: process.env.SMTP_PASS,
    },
    tls: {
      ciphers: 'SSLv3',
      rejectUnauthorized: true,
    },
  });
}

// ── INPUT VALIDATION ─────────────────────────────────────────────
function validateBody(body) {
  const errors = [];

  if (!body['record-description'] || body['record-description'].trim().length < 10) {
    errors.push('record-description: Please describe the records you are requesting (minimum 10 characters).');
  }
  if (body['record-description'] && body['record-description'].length > 2000) {
    errors.push('record-description: Description exceeds 2,000 character limit.');
  }
  if (!body['requester-name'] || body['requester-name'].trim().length < 2) {
    errors.push('requester-name: Please provide your full name.');
  }
  if (!body['requester-address'] || body['requester-address'].trim().length < 5) {
    errors.push('requester-address: Please provide your mailing address.');
  }
  if (!body['requester-email'] || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body['requester-email'].trim())) {
    errors.push('requester-email: Please provide a valid email address.');
  }

  return errors;
}

// ── SANITIZE ─────────────────────────────────────────────────────
function sanitize(str, maxLen = 500) {
  if (!str) return '';
  return String(str)
    .replace(/[<>]/g, '')   // strip angle brackets
    .replace(/\r\n|\r|\n/g, '\n')
    .trim()
    .slice(0, maxLen);
}

// ── CONFIRMATION EMAIL (to resident) ─────────────────────────────
function buildConfirmationEmail(data, ref) {
  const feeWaiver = data.feeWaiverRequested
    ? `\nFEE WAIVER REQUESTED: Yes\n${data.feeWaiverReason ? 'Reason: ' + data.feeWaiverReason + '\n' : ''}`
    : '\nFEE WAIVER REQUESTED: No\n';

  const text = `
Dear ${data.name},

Your Colorado Open Records Act (CORA) request has been received by the City of Colorado Springs.

REFERENCE NUMBER: ${ref}

Please save this reference number. Include it in any follow-up communications.

─────────────────────────────────────────────
WHAT YOU REQUESTED
─────────────────────────────────────────────
${data.description}
${data.dateRange ? '\nDate range: ' + data.dateRange : ''}
${data.documentNumber ? '\nDocument number: ' + data.documentNumber : ''}
${data.department ? '\nDepartment: ' + data.department : ''}
${feeWaiver}
─────────────────────────────────────────────
WHAT HAPPENS NEXT
─────────────────────────────────────────────

Within 3 working days: City staff will review your request. If records are readily
available, they may be provided immediately.

If more than 2 hours of staff time is needed: You will receive a cost estimate
before any charges are incurred. You may confirm, modify, or withdraw your
request at that point.

Up to 10 working days: If extenuating circumstances apply, the City may extend
the response period. You will be notified in writing before the initial 3-day
period expires.

If records are denied: You have the right to a written explanation citing the
specific statutory exemption under C.R.S. § 24-72-204.

─────────────────────────────────────────────
QUESTIONS?
─────────────────────────────────────────────

Phone: (719) 385-5906
Email: City.Communications@coloradosprings.gov
Mail:  City Clerk, 30 S. Nevada Ave., Suite 606, MC 660, Colorado Springs, CO 80903

If you need assistance or have a disability-related accommodation request, 
contact the Office of Accessibility: coloradosprings.gov/TitleIIADA

For information about your CORA rights:
Colorado Freedom of Information Coalition — coloradofoic.org

─────────────────────────────────────────────

This is an automated confirmation. Please do not reply to this email.
Reference: ${ref}
Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/Denver' })} Mountain Time

City of Colorado Springs · coloradosprings.gov/City-Clerk/CORA
`.trim();

  return {
    from:    `"City of Colorado Springs — CORA" <${process.env.SMTP_USER}>`,
    to:      data.email,
    subject: `CORA Request Received — Reference ${ref}`,
    text,
  };
}

// ── ROUTING EMAIL (to city staff) ─────────────────────────────────
function buildRoutingEmail(data, ref, routing) {
  const feeWaiver = data.feeWaiverRequested
    ? `YES${data.feeWaiverReason ? '\n   Reason: ' + data.feeWaiverReason : ''}`
    : 'No';

  const ada = data.adaRequested
    ? `YES${data.adaDetail ? '\n   Detail: ' + data.adaDetail : ''}`
    : 'No';

  const due = new Date();
  due.setDate(due.getDate() + 3); // 3 working days (simplified — adjust for holidays)
  const dueStr = due.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'America/Denver' });

  const text = `
NEW CORA REQUEST — ${ref}
City of Colorado Springs

Routed to: ${routing.label}
Response due by: ${dueStr} (3 working days from receipt)

─────────────────────────────────────────────
REQUESTER INFORMATION
─────────────────────────────────────────────
Name:    ${data.name}
Email:   ${data.email}
Phone:   ${data.phone || 'Not provided'}
Address: ${data.address}

─────────────────────────────────────────────
REQUEST DETAILS
─────────────────────────────────────────────
Records requested:
${data.description}

Date range:       ${data.dateRange || 'Not specified'}
Document number:  ${data.documentNumber || 'Not provided — requestor does not have one'}
Department:       ${data.department || 'Not specified — needs routing'}
Keywords/topic:   ${data.keywords || 'None provided'}
Format requested: ${data.format || 'Electronic'}

─────────────────────────────────────────────
SPECIAL HANDLING FLAGS
─────────────────────────────────────────────
Fee waiver requested:        ${feeWaiver}
ADA accommodation requested: ${ada}

─────────────────────────────────────────────
RESPONSE REQUIREMENTS (C.R.S. § 24-72-203)
─────────────────────────────────────────────
• Respond within 3 working days of receipt
• If extension needed: notify requester in writing before Day 3
• Maximum extension: 7 additional working days (total 10)
• If records denied: provide written statutory exemption under C.R.S. § 24-72-204
• If fee waiver requested: respond to waiver under C.R.S. § 24-72-205(6)
• First 2 hours of staff time: no charge to requester
• Fees beyond 2 hours: provide estimate before incurring

─────────────────────────────────────────────
ROUTING NOTE
─────────────────────────────────────────────
${data.department
    ? `Requester indicated: ${data.department}. Verify this is the correct department before proceeding. If records are held by another department, forward this email with the reference number.`
    : 'Requester did not specify a department. Please route to the correct department or respond to clarify. Do not delay the 3-day clock while routing.'}

─────────────────────────────────────────────

Reference: ${ref}
Submitted: ${new Date().toLocaleString('en-US', { timeZone: 'America/Denver' })} Mountain Time
Submission ID: ${uuid()}

City of Colorado Springs CORA Management System
`.trim();

  return {
    from:    `"CORA Submission System" <${process.env.SMTP_USER}>`,
    to:      routing.email,
    cc:      process.env.EMAIL_COORDINATOR || 'City.Communications@coloradosprings.gov',
    replyTo: data.email,
    subject: `[CORA] ${ref} — ${routing.label} — Due ${dueStr}`,
    text,
  };
}

// ── CORS HEADERS ─────────────────────────────────────────────────
const CORS_HEADERS = {
  'Access-Control-Allow-Origin':  process.env.ALLOWED_ORIGIN || 'https://coloradosprings.gov',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type':                 'application/json',
};

// ── MAIN FUNCTION ─────────────────────────────────────────────────
module.exports = async function (context, req) {
  context.log('CORA submission received');

  // ── PREFLIGHT ───────────────────────────────────────────────────
  if (req.method === 'OPTIONS') {
    context.res = { status: 204, headers: CORS_HEADERS, body: '' };
    return;
  }

  // ── METHOD CHECK ────────────────────────────────────────────────
  if (req.method !== 'POST') {
    context.res = {
      status: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: false, error: 'Method not allowed. Use POST.' }),
    };
    return;
  }

  // ── PARSE BODY ──────────────────────────────────────────────────
  const body = req.body || {};

  // ── HONEYPOT CHECK (simple bot detection) ───────────────────────
  // Add a hidden field called 'website' to the form. Humans leave it blank.
  if (body.website) {
    context.log('Honeypot triggered — likely bot submission');
    // Return success to avoid bot feedback loops
    context.res = {
      status: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: true, reference: 'CORA-BOT-FILTERED' }),
    };
    return;
  }

  // ── VALIDATE ────────────────────────────────────────────────────
  const errors = validateBody(body);
  if (errors.length > 0) {
    context.res = {
      status: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: false, errors }),
    };
    return;
  }

  // ── SANITIZE INPUT ───────────────────────────────────────────────
  const data = {
    description:       sanitize(body['record-description'], 2000),
    dateRange:         sanitize(body['date-range'], 200),
    documentNumber:    sanitize(body['doc-number'], 200),
    department:        sanitize(body['department'], 100),
    keywords:          sanitize(body['topic-keywords'], 200),
    format:            sanitize(body['format'], 50),
    feeWaiverRequested: !!body['fee-waiver'],
    feeWaiverReason:   sanitize(body['waiver-reason'], 500),
    adaRequested:      !!body['ada-request'],
    adaDetail:         sanitize(body['ada-detail'], 300),
    name:              sanitize(body['requester-name'], 100),
    address:           sanitize(body['requester-address'], 300),
    email:             sanitize(body['requester-email'], 200).toLowerCase(),
    phone:             sanitize(body['requester-phone'], 30),
  };

  // ── GENERATE REFERENCE ───────────────────────────────────────────
  const reference = generateReference();
  context.log(`CORA reference generated: ${reference}`);

  // ── RESOLVE ROUTING ──────────────────────────────────────────────
  const routing = DEPARTMENT_ROUTING[data.department] || DEFAULT_ROUTING;
  context.log(`Routing to: ${routing.label} <${routing.email}>`);

  // ── SEND EMAILS ──────────────────────────────────────────────────
  try {
    const transport = createTransport();

    // Verify SMTP connection (remove in production if causing delays)
    await transport.verify();
    context.log('SMTP connection verified');

    // Send confirmation to resident
    const confirmResult = await transport.sendMail(
      buildConfirmationEmail(data, reference)
    );
    context.log(`Confirmation sent to resident: ${confirmResult.messageId}`);

    // Send routing email to staff
    const routeResult = await transport.sendMail(
      buildRoutingEmail(data, reference, routing)
    );
    context.log(`Routing email sent to ${routing.email}: ${routeResult.messageId}`);

    // ── SUCCESS RESPONSE ─────────────────────────────────────────
    context.res = {
      status: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success:   true,
        reference,
        message:   `Your request has been received. Reference number: ${reference}. A confirmation has been sent to ${data.email}.`,
        routedTo:  routing.label,
      }),
    };

  } catch (emailError) {
    context.log.error('Email send failed:', emailError);

    // Return 202 Accepted — submission was valid even if email failed.
    // Log the submission so staff can recover it manually.
    context.log('FAILED SUBMISSION DATA:', JSON.stringify({ reference, data }));

    context.res = {
      status: 202,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success:   true,
        reference,
        message:   `Your request has been logged with reference ${reference}. There was a delay sending confirmation email — please call (719) 385-5906 to confirm receipt.`,
        warning:   'Email delivery delayed. Staff have been notified.',
      }),
    };
  }
};
