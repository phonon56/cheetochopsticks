# CORA Submission — Azure Function
**City of Colorado Springs · Accessible Records Request Handler**
Built by StorySeed / The Dais · Offered at no charge · April 2026

---

## What this does

Receives form submissions from the accessible CORA request form,
generates a reference number, sends a confirmation email to the
resident, and routes the request to the correct city department.

Replaces the inaccessible GovOutreach third-party portal.
No external vendor. No new contract. Runs on infrastructure the
City already has.

---

## Prerequisites

You need:

1. **Azure subscription** — the City's existing Azure tenant works
2. **Azure Functions** — available in all Azure subscriptions
3. **Microsoft 365 mailbox** — for SMTP relay (e.g. cora-noreply@coloradosprings.gov)
4. **Node.js 18+** — for local development and testing
5. **Azure Functions Core Tools v4** — for local testing

Install Core Tools:
```bash
npm install -g azure-functions-core-tools@4 --unsafe-perm true
```

---

## Step 1 — Set up the sending mailbox

Create a dedicated mailbox in Microsoft 365 admin:
`cora-noreply@coloradosprings.gov`

Generate an **App Password** (not the account password):
1. Sign in to account.microsoft.com as that user
2. Security → Advanced security options → App passwords
3. Create → name it "CORA Azure Function"
4. Copy the password — you will need it in Step 3

> **Why App Password?** Multi-factor authentication on Microsoft 365
> accounts blocks basic SMTP auth. App passwords bypass MFA for
> service accounts without disabling MFA on the account.

---

## Step 2 — Deploy to Azure

### Option A — Azure Portal (no CLI required)

1. Open portal.azure.com
2. Create a resource → Function App
3. Settings:
   - **Runtime stack**: Node.js
   - **Version**: 18 LTS
   - **Region**: East US (or Central US — closest to Colorado Springs)
   - **Plan**: Consumption (Serverless) — ~$0/month at city volume
   - **Storage account**: create new or use existing
4. After creation, go to the Function App → Functions → Add
5. Choose: HTTP trigger → Name it "CoraSubmit" → Authorization: Function
6. Replace the default code with the contents of `CoraSubmit/index.js`
7. Add `CoraSubmit/function.json` bindings via the portal editor

### Option B — Azure CLI (faster, recommended for IT)

```bash
# Login
az login

# Create resource group (or use existing)
az group create --name rg-cora-prod --location eastus

# Create storage account (needed by Functions)
az storage account create \
  --name stcoracosprod \
  --location eastus \
  --resource-group rg-cora-prod \
  --sku Standard_LRS

# Create Function App
az functionapp create \
  --resource-group rg-cora-prod \
  --consumption-plan-location eastus \
  --runtime node \
  --runtime-version 18 \
  --functions-version 4 \
  --name func-cora-cos-prod \
  --storage-account stcoracosprod

# Deploy the function code
cd /path/to/cora-azure-function
npm install
func azure functionapp publish func-cora-cos-prod
```

### Option C — GitHub Actions CI/CD (best for ongoing maintenance)

1. Push this repo to a private GitHub repository
2. In Azure portal: Function App → Deployment Center
3. Connect to GitHub → select the repo → save
4. Azure automatically deploys on every push to main

---

## Step 3 — Configure environment variables

In Azure portal: Function App → Configuration → Application settings

Add each of these as a new setting:

| Name | Value |
|------|-------|
| `SMTP_HOST` | `smtp.office365.com` |
| `SMTP_PORT` | `587` |
| `SMTP_USER` | `cora-noreply@coloradosprings.gov` |
| `SMTP_PASS` | *(the App Password from Step 1)* |
| `ALLOWED_ORIGIN` | `https://coloradosprings.gov` |
| `EMAIL_COORDINATOR` | `City.Communications@coloradosprings.gov` |
| `EMAIL_PROCUREMENT` | *(procurement staff email)* |
| `EMAIL_IT` | *(IT staff email)* |
| `EMAIL_PLANNING` | `PCDHearings@ElPasoCO.com` |
| `EMAIL_TRAFFIC` | `Traffic-Engineering.SMB@coloradosprings.gov` |
| `EMAIL_POLICE` | `pio@coloradosprings.gov` |
| `EMAIL_FIRE` | *(fire dept CORA email)* |
| `EMAIL_UTILITIES` | `coracustomerservices@csu.org` |
| `EMAIL_COURT` | `MunicipalCourtViolations@coloradosprings.gov` |
| `EMAIL_NEIGHBORHOOD` | *(neighborhood services email)* |
| `EMAIL_PUBLIC_WORKS` | *(public works email)* |
| `EMAIL_FINANCE` | *(finance email)* |
| `EMAIL_CITY_ATTORNEY` | *(city attorney email)* |
| `EMAIL_MAYOR` | *(mayor's office email)* |

Click **Save** after adding all settings.

> **Security**: Never put these values in `local.settings.json` in source
> control. The `.gitignore` below prevents accidental commits.

---

## Step 4 — Get the function URL

In Azure portal: Function App → Functions → CoraSubmit → Get Function URL

Copy the URL. It looks like:
```
https://func-cora-cos-prod.azurewebsites.net/api/cora-submit?code=ABC123...
```

This is your endpoint. The `?code=` parameter is the function key —
it prevents unauthorized submissions.

---

## Step 5 — Connect the form

In `cos-cora-form.html`, find this comment near the bottom of the script:

```javascript
// In production this would POST to a city endpoint
// Demo: show success state
```

Replace the submit handler block with:

```javascript
document.getElementById('cora-form').addEventListener('submit', async e => {
  e.preventDefault();
  if (!validate()) return;

  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  btn.textContent = 'Submitting…';

  const formData = {};
  new FormData(e.target).forEach((val, key) => { formData[key] = val; });

  try {
    const res = await fetch(
      'https://func-cora-cos-prod.azurewebsites.net/api/cora-submit?code=YOUR_FUNCTION_KEY',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      }
    );

    const data = await res.json();

    if (data.success) {
      document.getElementById('cora-form').style.display = 'none';
      const success = document.getElementById('success-panel');
      // Update success message with reference number
      success.querySelector('h2').textContent = 'Request submitted';
      success.querySelector('p').textContent =
        `Reference number: ${data.reference}. A confirmation has been sent to your email.`;
      success.classList.add('visible');
      success.focus();
    } else {
      btn.disabled = false;
      btn.textContent = 'Submit records request';
      alert('There was an error submitting your request. Please call (719) 385-5906.');
    }
  } catch (err) {
    btn.disabled = false;
    btn.textContent = 'Submit records request';
    alert('Connection error. Please call (719) 385-5906 or email City.Communications@coloradosprings.gov');
  }
});
```

---

## Step 6 — Test locally before going live

Copy the example settings file:
```bash
cp local.settings.json.example local.settings.json
```

Edit `local.settings.json` with real SMTP credentials.

Install dependencies:
```bash
npm install
```

Start the function locally:
```bash
func start
```

Run the test:
```bash
node test/test.js
```

Check that two emails arrive:
- Confirmation to `test@example.com` (your test address)
- Routing email to the procurement coordinator

---

## Step 7 — Add to the CORA page in Drupal

coloradosprings.gov runs Drupal. To embed the form:

**Option A — Iframe embed (fastest)**
Edit the CORA page in Drupal. Add an HTML block with:
```html
<iframe
  src="https://coloradosprings.gov/cora-form"
  title="CORA Records Request Form"
  width="100%"
  height="1200"
  frameborder="0"
  style="border:none;">
</iframe>
```
Host `cos-cora-form.html` as a static page on the city's web server.

**Option B — Native Drupal Webform (best long-term)**
See the Drupal Webform how-to in the accompanying documentation.
The Azure Function can be called from a Drupal Webform handler
via the Remote Post handler module.

**Option C — Replace GovOutreach links directly**
Replace each GovOutreach link on the CORA page with:
```html
<a href="/cora-submit?dept=procurement">
  Contracting / Procurement — Submit a CORA Request
</a>
```
Pass the department as a URL parameter and pre-select it in the form.

---

## Cost estimate

Azure Functions Consumption plan pricing (April 2026):
- First 1,000,000 executions/month: **free**
- After that: $0.20 per million executions

Colorado Springs CORA volume: estimated 200–500 submissions/month

**Monthly cost: $0.00**

The only ongoing cost is the Microsoft 365 mailbox — which the City
already pays for as part of its existing Microsoft agreement.

---

## .gitignore

Add this to the repository root before pushing to GitHub:

```
local.settings.json
node_modules/
.env
*.log
dist/
.funcignore
```

---

## Support

Questions about this implementation:
The Dais / StorySeed · See episode documentation for contact.

Questions about Azure Functions:
docs.microsoft.com/azure/azure-functions

Questions about CORA:
City.Communications@coloradosprings.gov · (719) 385-5906

Colorado Freedom of Information Coalition:
coloradofoic.org

---

*This code is offered to the City of Colorado Springs at no charge.
No invoice. No vendor contract. Just a form that works for everyone.*
