/**
 * Quick local test — simulates a valid CORA form submission
 * Run: node test/test.js
 * Requires the function running locally: func start
 */

const http = require('http');

const testPayload = JSON.stringify({
  'record-description': 'I am requesting all contracts between the City of Colorado Springs and Esri Inc. for ArcGIS software, including ArcGIS Online and ArcGIS Enterprise, from January 2020 through April 2026.',
  'date-range': 'January 2020 – April 2026',
  'doc-number': '',
  'department': 'procurement',
  'topic-keywords': 'Esri ArcGIS GIS software license',
  'format': 'electronic',
  'fee-waiver': true,
  'waiver-reason': 'Public interest — records relate to federally funded Safety Action Plan.',
  'ada-request': false,
  'ada-detail': '',
  'requester-name': 'Test Resident',
  'requester-address': '123 Test Street, Colorado Springs, CO 80903',
  'requester-email': 'test@example.com',
  'requester-phone': '(719) 555-0000',
  'website': '', // honeypot — must be empty
});

const options = {
  hostname: 'localhost',
  port: 7071,
  path: '/api/cora-submit',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(testPayload),
  },
};

console.log('Sending test CORA submission...\n');

const req = http.request(options, (res) => {
  let data = '';
  res.on('data', chunk => { data += chunk; });
  res.on('end', () => {
    console.log(`Status: ${res.statusCode}`);
    try {
      const parsed = JSON.parse(data);
      console.log('Response:', JSON.stringify(parsed, null, 2));
      if (parsed.success) {
        console.log(`\n✓ Reference number: ${parsed.reference}`);
        console.log(`✓ Routed to: ${parsed.routedTo}`);
        console.log('\nCheck the email addresses in local.settings.json for the confirmation and routing emails.');
      }
    } catch (e) {
      console.log('Raw response:', data);
    }
  });
});

req.on('error', (err) => {
  if (err.code === 'ECONNREFUSED') {
    console.error('Connection refused. Is the function running? Try: func start');
  } else {
    console.error('Error:', err.message);
  }
});

req.write(testPayload);
req.end();
